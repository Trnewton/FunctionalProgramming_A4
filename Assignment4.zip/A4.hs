module A4 where

{- This module is for playing with functions in ghci..
 - In other words, type
 -  ``ghci A4.hs``
 - so you can play with your code from the modules imported below..
 -}

import Lib.AST
import Lib.ASTParse
import TypeInference
import Examples
import Lib.Monads
